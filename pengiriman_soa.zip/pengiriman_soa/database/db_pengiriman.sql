-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 17 Jan 2023 pada 05.52
-- Versi server: 10.4.17-MariaDB
-- Versi PHP: 7.4.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_pengiriman`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `baju834`
--

CREATE TABLE `baju834` (
  `baju_id_834` int(11) NOT NULL,
  `nama_baju_834` varchar(30) NOT NULL,
  `brand_baju_834` varchar(100) NOT NULL,
  `material_baju_834` varchar(60) NOT NULL,
  `harga_baju_834` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `baju834`
--

INSERT INTO `baju834` (`baju_id_834`, `nama_baju_834`, `brand_baju_834`, `material_baju_834`, `harga_baju_834`) VALUES
(1, 'Baju A-1', 'Roughneck', 'Catoon', 'Rp.250.000'),
(2, 'Baju A-2', 'Roughneck', 'Catoon', 'Rp.250.000'),
(3, 'Baju A-1', 'Erigo', 'Catoon', 'Rp.100.000'),
(4, 'Baju A-2', 'Erigo', 'Nylon', 'Rp.150.000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `bajusales834`
--

CREATE TABLE `bajusales834` (
  `sale_id_834` int(11) NOT NULL,
  `sale_date_834` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `bajuk_id_834` int(11) NOT NULL,
  `customer_name_834` varchar(50) NOT NULL,
  `customer_phone_834` varchar(50) NOT NULL,
  `customer_address_834` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `bajusales834`
--

INSERT INTO `bajusales834` (`sale_id_834`, `sale_date_834`, `bajuk_id_834`, `customer_name_834`, `customer_phone_834`, `customer_address_834`) VALUES
(1, '2023-01-16 14:25:08', 3, 'Ridwan Agung', '089478310831', 'Kota Bandung. Kec, cibeunying kaler'),
(2, '2023-01-16 14:25:08', 4, 'Maulanna', '085329001673', 'Ujung Berung'),
(3, '2023-01-16 14:47:57', 5, 'Muhammad Raffi', '085389290102', 'Cicaheum 32 Bandung');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_biaya`
--

CREATE TABLE `tb_biaya` (
  `id_biaya` int(11) NOT NULL,
  `kabupaten` varchar(50) NOT NULL,
  `harga` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_biaya`
--

INSERT INTO `tb_biaya` (`id_biaya`, `kabupaten`, `harga`) VALUES
(1, 'Bandung', '2500'),
(2, 'Bandung Barat', '7000'),
(3, 'Bandung Timur', '5000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_kurir`
--

CREATE TABLE `tb_kurir` (
  `id_kurir` int(11) NOT NULL,
  `nama_kurir` varchar(35) NOT NULL,
  `no_telp` varchar(35) NOT NULL,
  `email_kurir` varchar(35) NOT NULL,
  `alamat_kurir` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_kurir`
--

INSERT INTO `tb_kurir` (`id_kurir`, `nama_kurir`, `no_telp`, `email_kurir`, `alamat_kurir`) VALUES
(1, 'Surya Saputra', '089467839001', 'Surya16@gmail.com', 'Juanda 3 Bandung'),
(2, 'Akbar', '083167390217', 'Akbar001@gmail.com', 'Buah Batu 18 Bandung'),
(3, 'Dimas Aji', '085670016793', 'Dim45@gmail.com', 'Soekarno Hatta 10 Bandung'),
(4, 'Joko', '083147902167', 'Jojobas99@gmail.com', 'Cimahi 21 Bandung Barat'),
(6, 'Damar', '081239034560', 'Damar001@gmail.com', 'Gajah mada 10 Bandung'),
(7, 'Rudiana', '089700379012', 'Rudi1100@gmail.com', 'Ujungberung 31 Bandung');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pengiriman`
--

CREATE TABLE `tb_pengiriman` (
  `id_pengiriman` varchar(50) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `id_kurir` int(11) NOT NULL,
  `nama_customer` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `alamat_pengiriman` text NOT NULL,
  `harga_barang` varchar(20) NOT NULL,
  `ongkos_kirim` varchar(20) NOT NULL,
  `tanggal_kirim` varchar(20) NOT NULL,
  `tanggal_sampai` varchar(20) NOT NULL,
  `status_pengiriman` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_pengiriman`
--

INSERT INTO `tb_pengiriman` (`id_pengiriman`, `sale_id`, `id_kurir`, `nama_customer`, `phone`, `nama_barang`, `alamat_pengiriman`, `harga_barang`, `ongkos_kirim`, `tanggal_kirim`, `tanggal_sampai`, `status_pengiriman`) VALUES
('63c2b2568def5', 2, 1, 'Maulanna', '083178930210', 'Baju A-1', 'Ujung Berung 06 Bandung', 'Rp.250.000', '2500', '2023-01-11 15:47:24', '', 'Dikirim'),
('63c54aa121983', 1, 2, 'Ridwan Agung', '089378390174', 'Baju A-1', 'Kota Bandung. Kec, cibeunying kaler', 'Rp.250.000', '2500', '2023-01-11 12:40:11', '2023-01-12 14:41:28', 'Terkirim'),
('63c54aa121988', 3, 1, 'Muhammad Raffi', '083389138903', 'Baju A-2', 'Cicaheum 32 Bandung', 'Rp.200.000', '2500', '2023-01-11 16:48:37', '', 'Dikirim');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `baju834`
--
ALTER TABLE `baju834`
  ADD PRIMARY KEY (`baju_id_834`);

--
-- Indeks untuk tabel `bajusales834`
--
ALTER TABLE `bajusales834`
  ADD PRIMARY KEY (`sale_id_834`);

--
-- Indeks untuk tabel `tb_biaya`
--
ALTER TABLE `tb_biaya`
  ADD PRIMARY KEY (`id_biaya`);

--
-- Indeks untuk tabel `tb_kurir`
--
ALTER TABLE `tb_kurir`
  ADD PRIMARY KEY (`id_kurir`);

--
-- Indeks untuk tabel `tb_pengiriman`
--
ALTER TABLE `tb_pengiriman`
  ADD PRIMARY KEY (`id_pengiriman`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `baju834`
--
ALTER TABLE `baju834`
  MODIFY `baju_id_834` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `bajusales834`
--
ALTER TABLE `bajusales834`
  MODIFY `sale_id_834` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tb_biaya`
--
ALTER TABLE `tb_biaya`
  MODIFY `id_biaya` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `tb_kurir`
--
ALTER TABLE `tb_kurir`
  MODIFY `id_kurir` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
